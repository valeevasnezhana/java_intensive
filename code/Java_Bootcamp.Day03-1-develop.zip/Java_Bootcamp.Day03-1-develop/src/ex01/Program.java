package ex01;

class Program {
    private static final Object lock = new Object();
    private static boolean isEggTurn = true;

    public static void main(String[] args) {
        int count;

        try {
            count = parseArgument(args[0]);
            if (count <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid arguments. Please provide valid " +
                    "thread count.");
            return;
        }

        for (int i = 0; i < count; i++) {
            Thread eggThread = new Thread(new EggRunnable());
            Thread henThread = new Thread(new HenRunnable());

            eggThread.start();
            henThread.start();

            try {
                eggThread.join();
                henThread.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private static int parseArgument(String arg) {
        if (arg.startsWith("--count=")) {
            return Integer.parseInt(arg.substring("--count=".length()));
        }
        return -1;
    }

    static class EggRunnable implements Runnable {
        @Override
        public void run() {
            synchronized (lock) {
                while (!isEggTurn) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                System.out.println("Egg");
                isEggTurn = false;
                lock.notify();
            }
        }
    }

    static class HenRunnable implements Runnable {
        @Override
        public void run() {
            synchronized (lock) {
                while (isEggTurn) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                System.out.println("Hen");
                isEggTurn = true;
                lock.notify();
            }
        }
    }
}