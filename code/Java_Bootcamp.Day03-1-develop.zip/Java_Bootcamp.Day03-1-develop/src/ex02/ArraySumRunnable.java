package ex02;

public class ArraySumRunnable implements Runnable {
    int[] array;
    final int[] sumsFromThreads;
    int startIndex, endIndex, threadIdx;

    public ArraySumRunnable(int[] array, int[] sumsFromThreads,
                            int startIndex, int endIndex, int threadIdx) {
        this.array = array;
        this.sumsFromThreads = sumsFromThreads;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.threadIdx = threadIdx;
    }

    @Override
    public void run() {
        int sum = 0;
        for (int j = startIndex; j < endIndex; j++) {
            sum += array[j];
        }
        synchronized (sumsFromThreads) {
            sumsFromThreads[threadIdx] = sum;
        }
        System.out.println(
                "Thread " + (threadIdx + 1) + ": from " + startIndex +
                        " to " + (endIndex - 1) + " sum is " + sum);
    }
}
