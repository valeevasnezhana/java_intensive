package ex02;

import java.util.Random;

public class Program {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java Program --arraySize=<size>" +
                    " --threadsCount=<count>");
            return;
        }

        int arraySize;
        int threadsCount;

        try {
            arraySize = parseArgument(args[0], "--arraySize=");
            threadsCount = parseArgument(args[1], "--threadsCount=");
            if (threadsCount <= 0 || arraySize < threadsCount) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid arguments. Please provide valid" +
                    " arguments for array size and thread count.");
            return;
        }

        int[] array = createRandomArray(arraySize);
        int expectedTotalSum = calculateSum(array);

        System.out.println("Sum: " + expectedTotalSum);

        Thread[] threads = new Thread[threadsCount];
        int sectionSize = (int) Math.ceil((double) arraySize / threadsCount);
        int[] sumsFromThreads = new int[threadsCount];

        for (int i = 0; i < threadsCount; i++) {
            final int startIndex = i * sectionSize;
            final int endIndex =
                    (i == threadsCount - 1) ? arraySize : (i + 1) * sectionSize;

            threads[i] = new Thread(
                    new ArraySumRunnable(array, sumsFromThreads, startIndex,
                            endIndex, i));
        }

        startThreads(threads);

        int totalSum = calculateSum(sumsFromThreads);

        System.out.println("Sum by threads: " + totalSum);
    }

    private static int parseArgument(String arg, String prefix) {
        if (arg.startsWith(prefix)) {
            return Integer.parseInt(arg.substring(prefix.length()));
        }
        return -1;
    }

    private static int[] createRandomArray(int arraySize) {
        int[] array = new int[arraySize];
        Random random = new Random();
        for (int i = 0; i < arraySize; i++) {
            array[i] = random.nextInt(2001) - 1000;
        }
        return array;
    }

    private static int calculateSum(int[] array) {
        int sum = 0;
        for (int num : array) {
            sum += num;
        }
        return sum;
    }

    private static void startThreads(Thread[] threads) {
        for (Thread value : threads) {
            value.start();
        }

        try {
            for (Thread thread : threads) {
                thread.join();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
