package ex00;

public class Program {
    private static final String ARG_START = "--count=";

    public static void main(String[] args) {

        if (args.length != 1 || !args[0].startsWith(ARG_START)) {
            System.err.println("Usage: java Program --count=<positive number>");
            System.exit(-1);
        }
        int count = Integer.parseInt(args[0].substring(ARG_START.length()));

        if (count <= 0) {
            System.out.println("Error: Incorrect input: " + count);
            System.exit(-1);
        }

        Runnable egg = () -> {
            for (int i = 0; i < count; i++) {
                System.out.println("Egg");
            }
        };

        Runnable hen = () -> {
            for (int i = 0; i < count; i++) {
                System.out.println("Hen");
            }
        };

        Thread eggThread = new Thread(egg);
        Thread henThread = new Thread(hen);

        eggThread.start();
        henThread.start();

        try {
            eggThread.join();
            henThread.join();
        } catch (InterruptedException e) {
            System.err.println("Thread interrupted: " + e.getMessage());
        }

        for (int i = 0; i < count; i++) {
            System.out.println("Human");
        }
    }
}
