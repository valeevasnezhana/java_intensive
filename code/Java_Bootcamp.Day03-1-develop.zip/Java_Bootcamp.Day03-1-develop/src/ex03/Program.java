package ex03;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Program {
    public static void main(String[] args) {
        int threadsCount = parseCommandLineArgs(args);

        if (threadsCount == -1) {
            System.out.println("Invalid incoming command line args");
            return;
        }

        String fileName = "files_urls.txt";

        ExecutorService executorService = Executors.newFixedThreadPool(threadsCount);

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            int urlNumber = 1;
            while (reader.readLine() != null) {
                executorService.execute(new DownloadTask(urlNumber));
                urlNumber++;
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        executorService.shutdown();
    }

    private static int parseCommandLineArgs(String[] args) {
        if (args.length == 1 && args[0].startsWith("--threadsCount=")) {
            return Integer.parseInt(args[0].substring("--threadsCount=".length()));
        }
        return -1;
    }

    static class DownloadTask implements Runnable {
        private final int urlNumber;

        public DownloadTask(int urlNumber) {
            this.urlNumber = urlNumber;
        }

        @Override
        public void run() {
            System.out.println(Thread.currentThread().getName() +
                    " start download file number " + urlNumber);
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            System.out.println(Thread.currentThread().getName() +
                    " finish download file number " + urlNumber);
        }
    }
}
