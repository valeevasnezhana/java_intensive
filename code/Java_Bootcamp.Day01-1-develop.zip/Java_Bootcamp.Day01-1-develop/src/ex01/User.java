package ex01;

public class User {
    private final int id;
    private final String name;
    private double balance;

    public User(String name, double balance) {
        this.id = UserIdsGenerator.getInstance().generateId();
        this.name = name;
        this.balance = Math.max(balance, 0);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = Math.max(balance, 0);
    }

    @Override
    public String toString() {
        return "User:" +
                "\nidentifier: " + id +
                "\nname: = " + name +
                "\nbalance: = " + balance + "\n";
    }
}