package ex01;
public class Program {
    public static void main(String[] args) {
        User user1 = new User("Biba", 100.0);
        User user2 = new User("Boba", 50.0);
        User user3 = new User("Aboba", 120.0);
        User user4 = new User("Abobus", 70.0);
        User user5 = new User("Amogus", 10.0);

        System.out.print(user1 + "\n");
        System.out.print(user2 + "\n");
        System.out.print(user3 + "\n");
        System.out.print(user4 + "\n");
        System.out.print(user5);
    }
}