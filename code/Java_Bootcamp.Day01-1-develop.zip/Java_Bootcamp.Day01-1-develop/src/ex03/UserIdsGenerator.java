package ex03;

public class UserIdsGenerator {
    private static final UserIdsGenerator GENERATOR = new UserIdsGenerator();
    private static int identifier = 0;

    private UserIdsGenerator() {
    }

    public static UserIdsGenerator getInstance() {
        return GENERATOR;
    }

    public int generateId() {
        ++identifier;
        return identifier;
    }
}
