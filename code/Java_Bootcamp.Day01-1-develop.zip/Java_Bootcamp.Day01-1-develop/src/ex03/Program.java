package ex03;

import java.util.UUID;

public class Program {
    public static void main(String[] args) {
        User user1 = new User("Biba", 100.0);
        User user2 = new User("Boba", 2000.0);

        System.out.println("Before transaction:");
        System.out.println(user1);
        System.out.println(user2);


        fillTransactionLists(user1, user2);
        TransactionsList user1Transactions = user1.getTransactionsList();
        TransactionsList user2Transactions = user2.getTransactionsList();

        System.out.println("User1 Transactions List" +
                " before deleting transaction:\n");

        Transaction[] user1TransactionArray = user1Transactions.toArray();

        for (Transaction transaction : user1TransactionArray) {
            System.out.println(transaction + "\n");
        }
        System.out.println("size = " + user1Transactions.getSize() + "\n");

        try {
            user1Transactions.removeTransactionById(
                    user1Transactions.toArray()[0].getId());
            System.out.println("existed Transaction " +
                    user1Transactions.toArray()[0].getId() + " deleted\n");

            user1Transactions.removeTransactionById(
                    UUID.randomUUID());
        } catch (TransactionNotFoundException e) {
            System.out.println(e.getMessage() + "\n");
        }

        Transaction[] user2TransactionArray = user2Transactions.toArray();
        user1TransactionArray = user1Transactions.toArray();

        System.out.println("User1 Transactions List:\n");

        for (Transaction transaction : user1TransactionArray) {
            System.out.println(transaction + "\n");
        }

        System.out.println("size = " + user1Transactions.getSize() + "\n");

        System.out.println("User2 Transactions List:\n");

        for (Transaction transaction : user2TransactionArray) {
            System.out.println(transaction + "\n");
        }

        System.out.println("size = " + user2Transactions.getSize() + "\n");
    }

    static void fillTransactionLists(User user1, User user2) {
        TransactionsLinkedList user1Transactions = new TransactionsLinkedList();
        TransactionsLinkedList user2Transactions = new TransactionsLinkedList();

        UUID transactionID = UUID.randomUUID();

        user2Transactions.addTransaction(new Transaction(transactionID,
                user1, user2, Transaction.TransactionCategory.DEBIT, 30.0));

        user1Transactions.addTransaction(new Transaction(transactionID,
                user2, user1, Transaction.TransactionCategory.CREDIT, -30.0));

        transactionID = UUID.randomUUID();

        user2Transactions.addTransaction(new Transaction(transactionID,
                user1, user2, Transaction.TransactionCategory.CREDIT, -20.0));
        user1Transactions.addTransaction(new Transaction(transactionID,
                user2, user1, Transaction.TransactionCategory.DEBIT, 20.0));

        user1.setTransactionsList(user1Transactions);
        user2.setTransactionsList(user2Transactions);
    }
}