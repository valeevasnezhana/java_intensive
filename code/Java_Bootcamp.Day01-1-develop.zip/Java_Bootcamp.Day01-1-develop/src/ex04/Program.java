package ex04;

public class Program {
    public static void main(String[] args) {
        TransactionsService transactionsService = new TransactionsService();

        User user1 = new User("John Doe", 100.0);
        User user2 = new User("Jane Doe", 50.0);
        transactionsService.addUser(user1);
        transactionsService.addUser(user2);

        transactionsService.performTransaction(user1.getId(),
                user2.getId(), 30.0);
        transactionsService.performTransaction(user2.getId(),
                user1.getId(), 20.0);

        Transaction[] user1Transactions = transactionsService
                .getUserTransactions(user1.getId());
        Transaction[] user2Transactions = transactionsService
                .getUserTransactions(user2.getId());

        System.out.println("User 1 Transactions:\n");
        for (Transaction transaction : user1Transactions) {
            System.out.println("\t" + transaction + "\n");
        }

        System.out.println("\nUser 2 Transactions:\n");
        for (Transaction transaction : user2Transactions) {
            System.out.println("\t" + transaction + "\n");
        }

        System.out.println("\nUser 1 balance:\n" +
                transactionsService.getUserBalance(user1.getId()));
        System.out.println("\nUser 2 balance:\n" +
                transactionsService.getUserBalance(user2.getId()));


        System.out.println("\ndeleting transaction:\n" + user1Transactions[0]);

        transactionsService.removeTransaction(user1.getId(),
                user1Transactions[0].getId());

        Transaction[] invalidTransactions =
                transactionsService.checkTransactionsValidity();

        System.out.println("\nInvalid Transactions:");
        for (Transaction transaction : invalidTransactions) {
            System.out.println(transaction);
        }
    }
}