package ex04;

public class User {
    private final int id;
    private final String name;
    private double balance;

    private TransactionsList userTransactions;

    public User(String name, double balance) {
        this.id = UserIdsGenerator.getInstance().generateId();
        this.name = name;
        this.balance = Math.max(balance, 0);
        this.userTransactions = new TransactionsLinkedList();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = Math.max(balance, 0);
    }

    public TransactionsList getTransactionsList() {
        return userTransactions;
    }

    public void setTransactionsList(TransactionsList transactionsList) {
        this.userTransactions = transactionsList;
    }

    @Override
    public String toString() {
        return "User:" +
                "\n\tidentifier: " + id +
                "\n\tname: = " + name +
                "\n\tbalance: = " + balance + "\n";

    }
}