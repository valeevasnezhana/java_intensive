package ex04;

import java.util.UUID;

class TransactionsLinkedList implements TransactionsList {
    private TransactionNode head;
    private int size;

    private static class TransactionNode {
        Transaction transaction;
        TransactionNode next;

        TransactionNode(Transaction transaction) {
            transaction.executeTransaction();
            this.transaction = transaction;
            this.next = null;
        }
    }

    public TransactionsLinkedList() {
        head = null;
        size = 0;
    }

    @Override
    public void addTransaction(Transaction transaction) {
        TransactionNode newNode = new TransactionNode(transaction);
        newNode.next = head;
        head = newNode;
        size++;
    }

    @Override
    public void removeTransactionById(UUID transactionId) throws
            TransactionNotFoundException {
        TransactionNode current = head;
        TransactionNode prev = null;

        while (current != null) {
            if (current.transaction.getId() == transactionId) {
                if (prev == null) {
                    head = current.next;
                } else {
                    prev.next = current.next;
                }
                size--;
                return;
            }
            prev = current;
            current = current.next;
        }

        throw new TransactionNotFoundException("Transaction with ID " +
                transactionId + " not found.");
    }

    public Transaction getTransactionById(UUID id) throws
            TransactionNotFoundException {
        TransactionNode current = head;
        while (current != null) {
            if (current.transaction.getId().compareTo(id) == 0) {
                return current.transaction;
            }
            current = current.next;
        }

        throw new TransactionNotFoundException("Transaction with ID " +
                id + " not found.");
    }

    @Override
    public Transaction[] toArray() {
        Transaction[] transactionArray = new Transaction[size];
        TransactionNode current = head;
        int index = size - 1;

        while (current != null) {
            transactionArray[index] = current.transaction;
            current = current.next;
            index--;
        }

        return transactionArray;
    }

    @Override
    public int getSize() {
        return size;
    }
}