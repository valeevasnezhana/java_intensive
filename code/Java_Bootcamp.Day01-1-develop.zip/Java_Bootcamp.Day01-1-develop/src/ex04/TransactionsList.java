package ex04;

import java.util.UUID;

public interface TransactionsList {

    void addTransaction(Transaction transaction);

    void removeTransactionById(UUID id);

    Transaction getTransactionById(UUID id);

    Transaction[] toArray();

    int getSize();

}
