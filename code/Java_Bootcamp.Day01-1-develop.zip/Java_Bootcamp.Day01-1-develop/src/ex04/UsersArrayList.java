package ex04;

public class UsersArrayList implements UsersList {

    private int numberOfUsers = 0;
    private int maxNumberOfUsers = 10;
    private User[] users = new User[maxNumberOfUsers];

    @Override
    public void addUser(User newUser) {
        if (numberOfUsers == maxNumberOfUsers) {
            maxNumberOfUsers *= 2;
            User[] tempUsers = new User[maxNumberOfUsers];
            if (numberOfUsers >= 0) {
                System.arraycopy(users, 0, tempUsers, 0, numberOfUsers);
            }
            users = tempUsers;
        }
        users[numberOfUsers++] = newUser;
    }

    @Override
    public User getUserById(int id) {
        for (int i = 0; i < numberOfUsers; i++) {
            if (users[i].getId() == id) {
                return users[i];
            }
        }
        throw new UserNotFoundException("user with id " + id + " is not found");
    }

    @Override
    public User getUserByIndex(int index) {
        if (index < 0 || index >= numberOfUsers) {
            throw new UserNotFoundException("index " + index + " is out of range");
        }
        return users[index];
    }

    @Override
    public int getUsersAmount() {
        return numberOfUsers;
    }

    @Override
    public void printList() {
        for (int i = 0; i < numberOfUsers; i++) {
            System.out.print((i + 1) + " " + users[i]);
        }
    }

    @Override
    public User[] toArray() {
        User[] usersArray = new User[numberOfUsers];
        System.arraycopy(users, 0, usersArray, 0, numberOfUsers);
        return usersArray;
    }
}
