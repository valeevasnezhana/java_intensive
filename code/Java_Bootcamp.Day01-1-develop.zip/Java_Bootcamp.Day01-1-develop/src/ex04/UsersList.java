package ex04;


public interface UsersList {
    void addUser(User newUser);

    User getUserById(int id);

    User getUserByIndex(int index);

    int getUsersAmount();

    User[] toArray();

    void printList();
}
