package ex04;

import java.util.UUID;

class TransactionsService {
    private final UsersList userList;

    public TransactionsService() {
        this.userList = new UsersArrayList();
    }

    public void addUser(User user) {

        userList.addUser(user);

    }

    public double getUserBalance(int userId) {
        User user = userList.getUserById(userId);
        return user.getBalance();
    }

    public void performTransaction(int senderId, int recipientId, double amount)
            throws IllegalTransactionException {
        User sender;
        User recipient;

        try {
            sender = userList.getUserById(senderId);
            recipient = userList.getUserById(recipientId);
        } catch (UserNotFoundException e) {
            throw new IllegalTransactionException(e.getMessage());
        }

        if (amount <= 0) {
            throw new IllegalTransactionException("Transfer amount must be" +
                    " positive floating-point value");
        }

        if (sender.getBalance() < amount) {
            throw new IllegalTransactionException("Insufficient balance" +
                    " for the transaction.");
        }

        UUID transactionID = UUID.randomUUID();
        Transaction debitTransaction = new Transaction(
                transactionID, sender, recipient,
                Transaction.TransactionCategory.DEBIT, amount);
        Transaction creditTransaction = new Transaction(
                transactionID, recipient, sender,
                Transaction.TransactionCategory.CREDIT, -amount);

        recipient.getTransactionsList().addTransaction(debitTransaction);
        sender.getTransactionsList().addTransaction(creditTransaction);
    }

    public Transaction[] getUserTransactions(int userId)
            throws UserNotFoundException {

        User user = userList.getUserById(userId);
        return user.getTransactionsList().toArray();
    }

    public void removeTransaction(int userId, UUID transactionId)
            throws TransactionNotFoundException {

        try {
            User user = userList.getUserById(userId);
            user.getTransactionsList().removeTransactionById(transactionId);
        } catch (UserNotFoundException | TransactionNotFoundException e) {
            throw new TransactionNotFoundException(e.getMessage());
        }
    }

    public Transaction[] checkTransactionsValidity() {
        TransactionsList invalidTransactions = new TransactionsLinkedList();

        for (User user : userList.toArray()) {
            Transaction[] userTransactions = user.getTransactionsList().toArray();

            for (Transaction transaction : userTransactions) {
                if (!isTransactionValid(transaction)) {
                    invalidTransactions.addTransaction(transaction);
                }
            }
        }

        return invalidTransactions.toArray();
    }

    private boolean isTransactionValid(Transaction transaction) {
        boolean result;
        try {
            Transaction pairTransaction = transaction.getRecipient()
                    .getTransactionsList()
                    .getTransactionById(transaction.getId());
            result = (pairTransaction.getAmount() == -transaction.getAmount());
            result &= (pairTransaction.getRecipient().getId() ==
                    transaction.getSender().getId());

            result &= (pairTransaction.getCategory()
                    != transaction.getCategory());

        } catch (TransactionNotFoundException e) {
            return false;
        }
        return result;
    }
}
