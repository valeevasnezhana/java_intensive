package ex05;

import java.util.UUID;

public class Transaction {
    private final UUID id;
    private final User recipient;
    private final User sender;
    private final TransactionCategory category;
    private int transferAmount;

    public enum TransactionCategory {
        DEBIT,
        CREDIT,
    }

    public Transaction(UUID identifier, User recipient, User sender,
                       TransactionCategory category, int amount) {
        this.id = identifier;
        this.recipient = recipient;
        this.sender = sender;
        this.category = category;
        this.transferAmount = amount;
    }

    public UUID getId() {
        return id;
    }

    public User getRecipient() {
        return recipient;
    }

    public User getSender() {
        return sender;
    }

    public TransactionCategory getCategory() {
        return category;
    }

    public int getAmount() {
        return transferAmount;
    }

    public void executeTransaction() {
        if ((category == TransactionCategory.DEBIT) && (validateDebit())) {
            sender.setBalance(sender.getBalance() + transferAmount);
            recipient.setBalance(recipient.getBalance() - transferAmount);
        } else if (category != TransactionCategory.CREDIT) {
            transferAmount = 0;
        }
    }

    private boolean validateDebit() {
        if (transferAmount <= 0) {
            return false;
        }
        return (recipient.getBalance() >= transferAmount);
    }

    @Override
    public String toString() {
        if (category == Transaction.TransactionCategory.CREDIT) {
            return ("To " +
                    recipient.getName() +
                    "(id = " + recipient.getId() + ") " +
                    transferAmount +
                    " with id = " +
                    id);
        } else {
            return ("From " +
                    recipient.getName() +
                    "(id = " + recipient.getId() + ") " +
                    transferAmount +
                    " with id = " +
                    id);
        }
    }
}