package ex05;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.UUID;

public class Menu {
    private final TransactionServiceInterface transactionsService;
    private final Scanner scanner;
    private final boolean isDevelopmentMode;

    public Menu(TransactionServiceInterface transactionsService,
                boolean isDevelopmentMode) {

        this.transactionsService = transactionsService;
        this.isDevelopmentMode = isDevelopmentMode;
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        while (true) {
            System.out.println("1. Add a user");
            System.out.println("2. View user balances");
            System.out.println("3. Perform a transfer");
            System.out.println("4. View all transactions for a specific user");

            if (isDevelopmentMode) {
                System.out.println("5. DEV - Remove a transfer by ID");
                System.out.println("6. DEV - Check transfer validity");
            }

            System.out.println("7. Finish execution");

            int choice = -1;

            while (choice == -1) {
                String input = scanner.next();
                try {
                    choice = Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid choice. Please enter integer.");
                }
            }

            switch (choice) {
                case 1:
                    addUser();
                    break;
                case 2:
                    viewUserBalances();
                    break;
                case 3:
                    performTransfer();
                    break;
                case 4:
                    viewUserTransactions();
                    break;
                case 5:
                    if (isDevelopmentMode) {
                        removeTransaction();
                    }
                    break;
                case 6:
                    if (isDevelopmentMode) {
                        checkTransferValidity();
                    }
                    break;
                case 7:
                    System.out.println("Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println("-----------------------------------------");
        }
    }

    private void addUser() {
        System.out.println("Enter a user name and a balance");
        String userName = scanner.next();
        int userBalance = -1;
        if (scanner.hasNextInt()) {
            userBalance = scanner.nextInt();
        }
        if (userBalance >= 0) {
            User newUser = new User(userName, userBalance);
            transactionsService.addUser(newUser);
            System.out.println("User with id = " +
                    newUser.getId() + " is added");
        } else {
            System.out.println("Balance must be non-negative" +
                    " floating-point value");
        }
    }

    private void viewUserBalances() {
        System.out.println("Enter a user ID");
        if (scanner.hasNextInt()) {
            int userId = scanner.nextInt();
            try {
                int balance = transactionsService.getUserBalance(userId);
                String name = transactionsService.getUserName(userId);
                System.out.printf("%s - %d\n", name, balance);
            } catch (UserNotFoundException e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("User identifier must be integer");
        }
    }

    private void performTransfer() {
        System.out.println("Enter a sender ID, a recipient ID, " +
                "and a transfer amount");
        int senderId;
        int recipientId;
        int transferAmount;

        try {
            senderId = scanner.nextInt();
            recipientId = scanner.nextInt();
            transferAmount = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Incorrect input");
            return;
        }

        try {
            transactionsService.performTransaction(
                    senderId, recipientId, transferAmount);

            System.out.println("The transfer is completed");
        } catch (IllegalTransactionException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void viewUserTransactions() {
        System.out.println("Enter a user ID");
        if (scanner.hasNextInt()) {
            int viewUserId = scanner.nextInt();
            try {
                Transaction[] transactions =
                        transactionsService.getUserTransactions(viewUserId);

                for (Transaction transaction : transactions) {
                    System.out.println(transaction);
                }
            } catch (UserNotFoundException e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("User identifier must be integer");
        }
    }

    private void removeTransaction() {
        System.out.println("Enter a user ID and a transfer ID");
        int userId = scanner.nextInt();
        UUID transactionId = UUID.fromString(scanner.next());

        try {

            String[] res = transactionsService
                    .removeTransaction(userId, transactionId);

            System.out.printf("Transfer %s %s(id = %s) %s removed\n",
                    res[0], res[1], res[2], res[3]);

        } catch (TransactionNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void checkTransferValidity() {
        Transaction[] invalidTransactions =
                transactionsService.checkTransactionsValidity();

        System.out.println("Check results:");

        if (invalidTransactions.length == 0) {
            System.out.println("There is no invalid transactions");
            return;
        }

        for (Transaction transaction : invalidTransactions) {
            if (transaction.getAmount() > 0) {
                System.out.printf("%s(id = %d) has an unacknowledged" +
                                " transfer id = %s from %s(id = %d) for %d\n",
                        transaction.getSender().getName(),
                        transaction.getSender().getId(),
                        transaction.getId().toString(),
                        transaction.getRecipient().getName(),
                        transaction.getRecipient().getId(),
                        transaction.getAmount());
            } else {
                System.out.printf("%s(id = %d) has an unacknowledged" +
                                " transfer id = %s to %s(id = %d) for %d\n",
                        transaction.getSender().getName(),
                        transaction.getSender().getId(),
                        transaction.getId().toString(),
                        transaction.getRecipient().getName(),
                        transaction.getRecipient().getId(),
                        -transaction.getAmount());
            }
        }
    }
}