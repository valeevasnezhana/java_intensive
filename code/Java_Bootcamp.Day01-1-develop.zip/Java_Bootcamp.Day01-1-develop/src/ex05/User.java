package ex05;

public class User {
    private final int id;
    private final String name;
    private int balance;

    private TransactionsList userTransactions;

    public User(String name, int balance) {
        this.id = UserIdsGenerator.getInstance().generateId();
        this.name = name;
        this.balance = Math.max(balance, 0);
        this.userTransactions = new TransactionsLinkedList();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = Math.max(balance, 0);
    }

    public TransactionsList getMutableTransactionsList() {
        return userTransactions;
    }

    @Override
    public String toString() {
        return "User:" +
                "\n\tidentifier: " + id +
                "\n\tname: = " + name +
                "\n\tbalance: = " + balance + "\n";

    }
}