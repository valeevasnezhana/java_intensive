package ex05;

import java.util.UUID;

class TransactionsService implements TransactionServiceInterface {
    private final UsersList userList;

    public TransactionsService() {
        this.userList = new UsersArrayList();
    }

    @Override
    public void addUser(User user) {

        userList.addUser(user);

    }

    @Override
    public int getUserBalance(int userId) {
        User user = userList.getUserById(userId);
        return user.getBalance();
    }

    @Override
    public String getUserName(int userId) {
        User user = userList.getUserById(userId);
        return user.getName();
    }

    @Override
    public void performTransaction(int senderId, int recipientId, int amount)
            throws IllegalTransactionException {
        User sender;
        User recipient;

        try {
            sender = userList.getUserById(senderId);
            recipient = userList.getUserById(recipientId);
        } catch (UserNotFoundException e) {
            throw new IllegalTransactionException(e.getMessage());
        }

        if (amount <= 0) {
            throw new IllegalTransactionException("Transfer amount must be" +
                    " positive floating-point value");
        }

        if (sender.getBalance() < amount) {
            throw new IllegalTransactionException("Insufficient balance" +
                    " for the transaction.");
        }

        UUID transactionID = UUID.randomUUID();
        Transaction debitTransaction = new Transaction(
                transactionID, sender, recipient,
                Transaction.TransactionCategory.DEBIT, amount);
        Transaction creditTransaction = new Transaction(
                transactionID, recipient, sender,
                Transaction.TransactionCategory.CREDIT, -amount);

        recipient.getMutableTransactionsList().addTransaction(debitTransaction);
        sender.getMutableTransactionsList().addTransaction(creditTransaction);
    }


    @Override
    public Transaction[] getUserTransactions(int userId)
            throws UserNotFoundException {

        User user = userList.getUserById(userId);
        return user.getMutableTransactionsList().toArray();
    }

    @Override
    public String[] removeTransaction(int userId, UUID transactionId)
            throws TransactionNotFoundException {

        try {
            String[] result = new String[4];
            User user = userList.getUserById(userId);
            Transaction transaction = user.getMutableTransactionsList()
                    .getTransactionById(transactionId);

            if (transaction.getAmount() > 0) {
                result[0] = "From";
                result[3] = Integer.toString(transaction.getAmount());
            } else {
                result[0] = "To";
                result[3] = Integer.toString(-transaction.getAmount());
            }

            result[1] = transaction.getRecipient().getName();
            result[2] = Integer.toString(transaction.getRecipient().getId());

            user.getMutableTransactionsList()
                    .removeTransactionById(transactionId);

            return result;
        } catch (UserNotFoundException | TransactionNotFoundException e) {
            throw new TransactionNotFoundException(e.getMessage());
        }
    }

    @Override
    public Transaction[] checkTransactionsValidity() {
        TransactionsList invalidTransactions = new TransactionsLinkedList();

        for (User user : userList.toArray()) {
            Transaction[] userTransactions = user
                    .getMutableTransactionsList().toArray();

            for (Transaction transaction : userTransactions) {
                if (!isTransactionValid(transaction)) {
                    invalidTransactions.addTransaction(transaction);
                }
            }
        }

        return invalidTransactions.toArray();
    }

    private boolean isTransactionValid(Transaction transaction) {
        boolean result;
        try {
            Transaction pairTransaction = transaction.getRecipient()
                    .getMutableTransactionsList()
                    .getTransactionById(transaction.getId());
            result = (pairTransaction.getAmount() == -transaction.getAmount());
            result &= (pairTransaction.getRecipient().getId() ==
                    transaction.getSender().getId());

            result &= (pairTransaction.getCategory()
                    != transaction.getCategory());

        } catch (TransactionNotFoundException e) {
            return false;
        }
        return result;
    }
}
