package ex05;

public class Program {
    public static void main(String[] args) {
        boolean isDevelopmentMode = (args.length > 0) &&
                (args[0].equals("--profile=dev"));

        TransactionsService transactionsService = new TransactionsService();

        Menu menu = new Menu(transactionsService, isDevelopmentMode);
        menu.run();
    }
}