package ex05;

import java.util.UUID;

interface TransactionServiceInterface {
    void addUser(User user);

    Transaction[] checkTransactionsValidity();

    String[] removeTransaction(int userId, UUID transactionId)
            throws TransactionNotFoundException;

    Transaction[] getUserTransactions(int userId) throws UserNotFoundException;

    void performTransaction(int senderId, int recipientId, int amount)
            throws IllegalTransactionException;

    int getUserBalance(int userId);
    String getUserName(int userId);
}
