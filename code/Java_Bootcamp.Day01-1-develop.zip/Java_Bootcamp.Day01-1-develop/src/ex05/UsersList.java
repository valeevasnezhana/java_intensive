package ex05;


public interface UsersList {
    void addUser(User newUser);

    User getUserById(int id) throws UserNotFoundException;

    User getUserByIndex(int index);

    int getUsersAmount();

    User[] toArray();
}
