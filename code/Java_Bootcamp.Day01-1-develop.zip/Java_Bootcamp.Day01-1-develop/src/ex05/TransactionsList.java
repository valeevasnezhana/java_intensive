package ex05;

import java.util.UUID;

public interface TransactionsList {

    void addTransaction(Transaction transaction);

    void removeTransactionById(UUID id) throws
            TransactionNotFoundException;

    Transaction getTransactionById(UUID id);

    Transaction[] toArray();

    int getSize();

}
