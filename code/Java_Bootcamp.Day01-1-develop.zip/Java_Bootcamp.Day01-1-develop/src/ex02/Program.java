package ex02;

public class Program {
    public static void main(String[] args) {
        UsersList usersList = new UsersArrayList();

        usersList.addUser(new User("Biba", 100.0));
        usersList.addUser(new User("Boba", 50.0));
        usersList.addUser(new User("Aboba", 120.0));
        usersList.addUser(new User("Abobus", 70.0));
        usersList.addUser(new User("Amogus", 10.0));


        System.out.println("trying to get last user(5) and next after" +
                " last(6) by ID:");
        try {
            User user = usersList.getUserById(5);
            System.out.println("User found: " + user);
            user = usersList.getUserById(6);
            System.out.println("User found: " + user);
        } catch (UserNotFoundException e) {
            System.out.println("User not found: " + e.getMessage());
        }

        System.out.println("\ntrying to get last user(4) and next after" +
                " last(5) by list index: ");
        try {
            User user = usersList.getUserByIndex(4);
            System.out.println("User found: " + user);
            user = usersList.getUserByIndex(5);
            System.out.println("User found: " + user);
        } catch (UserNotFoundException e) {
            System.out.println("User not found: " + e.getMessage());
        }

        usersList.printList();

        for (int i = 6; i < 30; i++) {
            usersList.addUser(new User("User" + i, 1));
        }

        int userCount = usersList.getUsersAmount();
        System.out.println("\n after adding new users, users amount: " +
                userCount);

        System.out.println("List: ");
        usersList.printList();
    }
}
