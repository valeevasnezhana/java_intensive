package ex02;

public interface UsersList {
    void addUser(User newUser);

    User getUserById(int id);

    User getUserByIndex(int index);

    int getUsersAmount();

    void printList();
}
