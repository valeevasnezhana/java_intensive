package ex00;

import java.util.UUID;

public class Transaction {
    private final UUID id;
    private final User recipient;
    private final User sender;
    private final TransactionCategory category;
    private double transferAmount;

    public enum TransactionCategory {
        DEBIT,
        CREDIT,
    }

    public Transaction(UUID identifier, User recipient, User sender,
                       TransactionCategory category, double amount) {
        this.id = identifier;
        this.recipient = recipient;
        this.sender = sender;
        this.category = category;
        this.transferAmount = amount;
    }

    public UUID getId() {
        return id;
    }

    public User getRecipient() {
        return recipient;
    }

    public User getSender() {
        return sender;
    }

    public String getCategory() {
        return category.toString();
    }

    public double getAmount() {
        return transferAmount;
    }

    public void executeTransaction() {
        if ((category == TransactionCategory.DEBIT) && (validateDebit())) {
            sender.setBalance(sender.getBalance() + transferAmount);
            recipient.setBalance(recipient.getBalance() - transferAmount);
        } else if (category != TransactionCategory.CREDIT) {
            transferAmount = 0;
        }
    }

    private boolean validateDebit() {
        if (transferAmount <= 0) {
            return false;
        }
        return (recipient.getBalance() >= transferAmount);
    }

    @Override
    public String toString() {
        return "Transaction:" +
                "\nidentifier = " + id +
                "\nrecipient = " + recipient.getName() +
                "\nsender = " + sender.getName() +
                "\ntransferCategory = " + category +
                "\ntransferAmount = " + transferAmount + "\n";
    }
}