package ex00;

import java.util.UUID;

public class Program {
    public static void main(String[] args) {
        User user1 = new User(1, "Biba", 100.0);
        User user2 = new User(2, "Boba Aboba", 50.0);

        UUID transactionID = UUID.randomUUID();
        Transaction transaction = new Transaction(transactionID, user2, user1,
                Transaction.TransactionCategory.CREDIT, -30.0);
        Transaction transaction2 = new Transaction(transactionID, user1, user2,
                Transaction.TransactionCategory.DEBIT, 30.0);

        System.out.print("Before transaction:\n\n");

        System.out.print(user1 + "\n");
        System.out.print(user2 + "\n");

        System.out.println("Transaction:" +
                "\nidentifier = " + transaction.getId() +
                "\nrecipient = " + transaction.getRecipient().getName() +
                "\nsender = " + transaction.getSender().getName() +
                "\ntransferCategory = " + transaction.getCategory() +
                "\ntransferAmount = " + transaction.getAmount() + "\n");
        System.out.print(transaction2);

        transaction.executeTransaction();
        transaction2.executeTransaction();

        System.out.print("\nAfter transaction:\n\n");
        System.out.print(user1 + "\n");
        System.out.print(user2);
    }
}