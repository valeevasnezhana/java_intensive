package ex02;

import java.io.IOException;
import java.nio.file.*;
import java.util.Scanner;

public class Program {
    private static String currentDirectory;

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java Program <folder_path>");
            return;
        }

        currentDirectory = args[0];

        try (Scanner scanner = new Scanner(System.in)) {
            boolean needToContinue = true;
            while (needToContinue) {
                System.out.print(currentDirectory + " $ ");
                String input = scanner.nextLine();
                needToContinue = executeCommand(input);
            }
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

    private static boolean executeCommand(String input) throws IOException {
        String[] parts = input.split(" ");
        String command = parts[0];

        switch (command) {
            case "ls":
                listContents();
                return true;
            case "cd":
                if (parts.length > 1) {
                    changeDirectory(parts[1]);
                } else {
                    System.err.println("Usage: cd FOLDER_NAME");
                }
                return true;
            case "mv":
                if (parts.length > 2) {
                    moveFile(parts[1], parts[2]);
                } else {
                    System.err.println("Usage: mv WHAT WHERE");
                }
                return true;
            case "exit":
                return false;
            default:
                System.err.println("Unknown command: " + command);
                return true;
        }
    }

    private static void listContents() throws IOException {
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(
                Paths.get(currentDirectory))) {
            for (Path entry : stream) {
                String name = entry.getFileName().toString();
                long size = Files.isDirectory(entry) ? getFolderSize(entry) :
                        Files.size(entry) / 1024;
                System.out.println(name + " (" + size + " KB)");
            }
        }
    }

    private static void changeDirectory(String folderName) {
        if (folderName.equals("..")) {
            Path parent = Paths.get(currentDirectory).getParent();
            if (parent != null) {
                currentDirectory = parent.toString();
            } else {
                System.err.println("Already at the root directory.");
            }
        } else {
            Path newDir = Paths.get(currentDirectory, folderName);
            if (Files.isDirectory(newDir)) {
                currentDirectory = newDir.toString();
            } else {
                System.err.println("Folder not found: " + folderName);
            }
        }
    }

    private static void moveFile(String source, String destination)
            throws IOException {
        Path sourcePath = Paths.get(currentDirectory, source);
        Path destinationPath = Paths.get(currentDirectory, destination);

        if (Files.exists(sourcePath)) {
            if (Files.isDirectory(destinationPath)) {
                destinationPath =
                        destinationPath.resolve(sourcePath.getFileName());
            }

            Files.move(sourcePath, destinationPath,
                    StandardCopyOption.REPLACE_EXISTING);
        } else {
            System.err.println("File not found: " + source);
        }
    }

    private static long getFolderSize(Path folder) throws IOException {
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder)) {
            long size = 0;
            for (Path entry : stream) {
                if (Files.isDirectory(entry)) {
                    size += getFolderSize(entry);
                } else {
                    size += Files.size(entry) / 1024;
                }
            }
            return size;
        }
    }
}
