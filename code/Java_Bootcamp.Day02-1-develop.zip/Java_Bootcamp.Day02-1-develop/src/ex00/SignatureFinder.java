package ex00;

import java.io.FileInputStream;
import java.io.IOException;


public class SignatureFinder {

    public static String getFileType(SignaturesReference signatures,
                                     String filePath) {

        if (signatures.getStatus() == SignaturesReference.Status.ERROR) {
            return "";
        }

        String fileSignature = findSignature(signatures, filePath);

        if (fileSignature.isEmpty()) {
            return "";
        }

        for (String key : signatures.getSignatures().keySet()) {
            String overlap;
            if (fileSignature.length() >= key.length()) {
                overlap = fileSignature.substring(0, key.length());
            } else {
                continue;
            }
            if (overlap.equalsIgnoreCase(key))
                return signatures.getSignatures().get(key);
        }
        return "";
    }

    private static String findSignature(SignaturesReference signatures,
                                        String filePath) {

        try (FileInputStream reader = new FileInputStream(filePath)) {
            int byteRead;
            StringBuilder textFromFile = new StringBuilder();
            while (((byteRead = reader.read()) != '\n') &&
                    (textFromFile.length() < signatures.getMaxSignatureLen())) {

                if (textFromFile.length() > 0) {
                    textFromFile.append(" ");
                }
                textFromFile.append(String.format("%02X", byteRead));
            }
            return textFromFile.toString();

        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
            return "";
        }
    }

}
