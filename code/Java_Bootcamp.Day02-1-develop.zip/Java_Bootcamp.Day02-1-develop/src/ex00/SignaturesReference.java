package ex00;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class SignaturesReference {
    public enum Status {
        OK, ERROR
    }

    private Status status;
    private final Map<String, String> signatures;
    private int maxSignatureLen;

    public Status getStatus() {
        return status;
    }

    public Map<String, String> getSignatures() {
        return signatures;
    }

    public int getMaxSignatureLen() {
        return maxSignatureLen;
    }


    public SignaturesReference(String filePath) {
        signatures = new HashMap<>();
        maxSignatureLen = 0;
        status = Status.ERROR;
        try {
            FileInputStream signaturesFile = new FileInputStream(filePath);

            byte[] buffer = new byte[1024];
            StringBuilder signaturesContent = new StringBuilder();
            int bytesRead;
            while ((bytesRead = signaturesFile.read(buffer)) != -1) {
                signaturesContent.append(new String(buffer, 0, bytesRead));
            }
            signaturesFile.close();

            String[] signatureLines = signaturesContent.toString().split("\n");
            for (String line : signatureLines) {
                String[] parts = line.split(", ");
                if (parts.length == 2) {
                    String fileType = parts[0];
                    String signature = parts[1];
                    signatures.put(signature, fileType);
                    status = Status.OK;
                    if (signature.length() > maxSignatureLen) {
                        maxSignatureLen = signature.length();
                    }
                } else {
                    status = Status.ERROR;
                }
            }

        } catch (IOException e) {
            System.err.println("Error reading signatures file: " +
                    e.getMessage());
            status = Status.ERROR;
        }
    }
}
