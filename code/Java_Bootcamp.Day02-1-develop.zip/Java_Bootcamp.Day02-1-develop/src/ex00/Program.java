package ex00;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;


public class Program {
    public static void main(String[] args) {
        SignaturesReference signatures = new SignaturesReference(
                "src/ex00/signatures.txt");

        if (signatures.getStatus() == SignaturesReference.Status.ERROR) {
            System.out.println("Signatures file is invalid");
            return;
        }
        Scanner scanner = new Scanner(System.in);
        try (FileOutputStream fileWriter = new FileOutputStream(
                "src/ex00/result.txt")) {
            while (true) {
                String userInput = scanner.nextLine();
                if (userInput.equals("42")) {
                    break;
                }

                String fileType = SignatureFinder
                        .getFileType(signatures, userInput);

                if (!fileType.isEmpty()) {
                    fileWriter.write((fileType + "\n").getBytes());
                    fileWriter.flush();
                    System.out.println("PROCESSED");
                } else {
                    System.out.println("UNDEFINED");
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}



