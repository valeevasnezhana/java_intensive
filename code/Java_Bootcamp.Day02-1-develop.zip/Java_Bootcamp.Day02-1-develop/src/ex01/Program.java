package ex01;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Program {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: Program <file1> <file2>");
            return;
        }

        String file1 = args[0];
        String file2 = args[1];

        Map<String, Integer> wordFrequency1 = new HashMap<>();
        Map<String, Integer> wordFrequency2 = new HashMap<>();

        try {
            calculateWordFrequency(file1, wordFrequency1);
            calculateWordFrequency(file2, wordFrequency2);
        } catch (IOException e) {
            System.err.println("Failed to read one or both files.");
            return;
        }

        double similarity =
                calculateCosineSimilarity(wordFrequency1, wordFrequency2);

        System.out.println("Similarity = " +
                String.format("%.2f", Math.floor(similarity * 100) / 100));

        try {
            writeDictionaryToFile(wordFrequency1,
                    wordFrequency2);
        } catch (IOException e) {
            System.err.println("Failed to write the dictionary to the file.");
        }
    }

    private static void calculateWordFrequency(String filename,
                                               Map<String, Integer> wordFrequency)
            throws
            IOException {

        try (BufferedReader reader = new BufferedReader(
                new FileReader(filename))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+");
                for (String word : words) {
                    wordFrequency.put(word,
                            wordFrequency.getOrDefault(word, 0) + 1);

                }
            }
        }
    }

    private static double calculateCosineSimilarity(
            Map<String, Integer> vector1, Map<String, Integer> vector2) {
        Set<String> commonWords = new HashSet<>(vector1.keySet());
        commonWords.retainAll(vector2.keySet());

        double dotProduct = 0.0;
        double magnitude1 = 0.0;
        double magnitude2 = 0.0;

        for (String word : commonWords) {
            dotProduct += vector1.get(word) * vector2.get(word);
        }

        for (Integer value : vector1.values()) {
            magnitude1 += value * value;
        }

        for (Integer value : vector2.values()) {
            magnitude2 += value * value;
        }

        if (magnitude1 == 0.0 || magnitude2 == 0.0) {
            return 0.0;
        }

        return dotProduct / (Math.sqrt(magnitude1) * Math.sqrt(magnitude2));
    }

    private static void writeDictionaryToFile(Map<String, Integer> dict1,
                                              Map<String, Integer> dict2) throws
            IOException {

        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter("dictionary.txt"))) {
            writer.write("Dictionary 1:\n");
            for (Map.Entry<String, Integer> entry : dict1.entrySet()) {
                writer.write(entry.getKey() + ": " + entry.getValue() + "\n");
            }

            writer.write("\nDictionary 2:\n");
            for (Map.Entry<String, Integer> entry : dict2.entrySet()) {
                writer.write(entry.getKey() + ": " + entry.getValue() + "\n");
            }
        }
    }
}
